<?php
/**
 * Pour gérer configurations par défaut + override externe. Non utilisé pour le moment.
 *
 * @package     Platform-Shell
 */

return [
	/* Rien pour le moment. */
];
