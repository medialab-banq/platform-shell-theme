Partial / modified source of a php / wordpress compatible autoloader distributed under GLP3 licence.
See also : https://tommcfarlin.com/namespaces-and-autoloading-2017/

This version contains only the autoloader, see the original repository for complete sources.
https://github.com/tommcfarlin/namespaces-and-autoloading-in-wordpress/

Changes :
- Add fake namespace to reducre risk of conflict.
- Limit namespace https://www.smashingmagazine.com/2015/05/how-to-use-autoloading-and-a-plugin-container-in-wordpress-plugins/