=== Plateforme médialab BAnQ ===
Contributors: Bibliothèque et Archives nationales du Québec (BAnQ)
Tags: medialab
Requires at least: 4.9.4
Tested up to: 4.9.5
Stable tag: 1.0.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extension WordPress permettant de créer une plateforme de médialab collaborative.

== Description ==

Extension WordPress permettant de créer une plateforme de médialab collaborative.

* Voir aussi :
    * Le fichier README.MD dans le dossier de l'extension ou en ligne sur [Github](https://github.com/medialab-banq/platform-shell-plugin/).
    * Le [wiki](https://github.com/medialab-banq/platform-shell-plugin/wiki) du projet.

== Installation ==

* Voir la procédure d’installation de la plateforme dans le [wiki](https://github.com/medialab-banq/platform-shell-plugin/wiki) du projet.
* Installer le plugin comme n'importe laquelle autre extension WordPress.

== Changelog ==

= 1.0.0 =
* Version initiale.

= 1.0.1 =
* Corrections de problèmes mineurs.
    * Erreur script lors du signalement de projet cause blocage de l'affichage.
    * Accès Apparence / Personnaliser cause erreur php.
    * Restriction courriel incorrecte du courriel gestionnaire.
	* Ajout temporaire du dossier vendor (enlève ignore rule) + correction pour prochaine mise à jour et permettre utilisation du .zip d'un release.
